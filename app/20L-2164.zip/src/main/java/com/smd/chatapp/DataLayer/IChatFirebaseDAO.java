package com.smd.chatapp.DataLayer;

import com.smd.chatapp.BusinessLayer.Message;

import java.util.ArrayList;

public interface IChatFirebaseDAO {
    void save(Message msg, String chatId);
    void loadMessagesForChat(String chatId, MessagesCallback callback);
    ArrayList<Message>load();
}
